import React, { useState } from 'react';
import { LayoutDashboard, FlaskRound, UserCircle, Settings, MessageSquare, LogOut, Moon, Sun, Users, Stethoscope, BedDouble, UserCheck } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Legend
} from 'recharts';

const lineChartData = [
  { name: 'Jan', covid: 65, flu: 28, pneumonia: 45 },
  { name: 'Feb', covid: 59, flu: 48, pneumonia: 38 },
  { name: 'Mar', covid: 80, flu: 40, pneumonia: 43 },
  { name: 'Apr', covid: 81, flu: 19, pneumonia: 41 },
  { name: 'May', covid: 56, flu: 24, pneumonia: 33 },
  { name: 'Jun', covid: 55, flu: 27, pneumonia: 39 }
];

const barChartData = [
  { week: 'Week 1', inPatients: 45, outPatients: 28 },
  { week: 'Week 2', inPatients: 52, outPatients: 35 },
  { week: 'Week 3', inPatients: 49, outPatients: 42 },
  { week: 'Week 4', inPatients: 47, outPatients: 45 }
];

const recentPatients = [
  { id: 1, name: 'Sarah Johnson', age: 45, disease: 'Pneumonia', status: 'Diagnosed', admitted: 'Yes' },
  { id: 2, name: 'Michael Chen', age: 32, disease: 'COVID-19', status: 'Under Treatment', admitted: 'Yes' },
  { id: 3, name: 'Emily Davis', age: 28, disease: 'Influenza', status: 'Recovered', admitted: 'No' },
  { id: 4, name: 'Robert Wilson', age: 56, disease: 'Hypertension', status: 'Monitoring', admitted: 'No' },
  { id: 5, name: 'Lisa Anderson', age: 39, disease: 'Diabetes', status: 'Stable', admitted: 'No' }
];

const Dashboard = () => {
  const [darkMode, setDarkMode] = useState(false);
  const navigate = useNavigate();

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    document.documentElement.classList.toggle('dark');
  };

  return (
    <div className={`min-h-screen flex ${darkMode ? 'dark bg-gray-900' : 'bg-gray-100'}`}>
      {/* Sidebar */}
      <div className={`w-64 ${darkMode ? 'bg-gray-800' : 'bg-white'} shadow-lg`}>
        <div className="p-6">
          <div className="flex items-center gap-3 mb-8">
            <Stethoscope className={`h-8 w-8 ${darkMode ? 'text-blue-400' : 'text-blue-600'}`} />
            <span className={`text-xl font-bold ${darkMode ? 'text-white' : 'text-gray-800'}`}>MediTech AI</span>
          </div>
          
          <nav className="space-y-2">
            {[
              { icon: LayoutDashboard, text: 'Dashboard', path: '/dashboard' },
              { icon: FlaskRound, text: 'Tests', path: '/test' },
              { icon: UserCircle, text: 'Profile' },
              { icon: Settings, text: 'Settings' },
              { icon: MessageSquare, text: 'Consultation' },
              { icon: LogOut, text: 'Logout' }
            ].map((item, index) => (
              <button
                key={index}
                onClick={() => item.path && navigate(item.path)}
                className={`w-full flex items-center gap-3 px-4 py-2 rounded-lg transition-colors
                  ${darkMode 
                    ? 'text-gray-300 hover:bg-gray-700 hover:text-white' 
                    : 'text-gray-600 hover:bg-blue-50 hover:text-blue-600'}`}
              >
                <item.icon className="h-5 w-5" />
                <span>{item.text}</span>
              </button>
            ))}
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-8">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="flex justify-between items-center mb-8">
            <div>
              <h1 className={`text-2xl font-bold ${darkMode ? 'text-white' : 'text-gray-800'}`}>
                Welcome, Dr. Sarah Williams!
              </h1>
              <p className={`${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                Here's your hospital overview
              </p>
            </div>
            <button
              onClick={toggleDarkMode}
              className={`p-2 rounded-lg ${darkMode ? 'bg-gray-700 text-yellow-400' : 'bg-gray-200 text-gray-600'}`}
            >
              {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </button>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {[
              { icon: Users, title: 'Total Patients', value: '1,284', color: 'blue' },
              { icon: Stethoscope, title: 'Diagnosed Cases', value: '864', color: 'green' },
              { icon: BedDouble, title: 'Admitted Patients', value: '146', color: 'yellow' },
              { icon: UserCheck, title: 'Discharged', value: '68', color: 'purple' }
            ].map((stat, index) => (
              <div
                key={index}
                className={`${darkMode ? 'bg-gray-800' : 'bg-white'} rounded-xl shadow-lg p-6`}
              >
                <div className="flex items-center gap-4">
                  <div className={`p-3 rounded-lg bg-${stat.color}-100`}>
                    <stat.icon className={`h-6 w-6 text-${stat.color}-600`} />
                  </div>
                  <div>
                    <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>{stat.title}</p>
                    <p className={`text-2xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>{stat.value}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <div className={`${darkMode ? 'bg-gray-800' : 'bg-white'} p-6 rounded-xl shadow-lg`}>
              <h3 className={`text-lg font-semibold mb-4 ${darkMode ? 'text-white' : 'text-gray-800'}`}>
                Disease Trends
              </h3>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={lineChartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" stroke={darkMode ? '#9CA3AF' : '#6B7280'} />
                    <YAxis stroke={darkMode ? '#9CA3AF' : '#6B7280'} />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="covid" stroke="#3B82F6" />
                    <Line type="monotone" dataKey="flu" stroke="#10B981" />
                    <Line type="monotone" dataKey="pneumonia" stroke="#F59E0B" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className={`${darkMode ? 'bg-gray-800' : 'bg-white'} p-6 rounded-xl shadow-lg`}>
              <h3 className={`text-lg font-semibold mb-4 ${darkMode ? 'text-white' : 'text-gray-800'}`}>
                Patient Reports
              </h3>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={barChartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="week" stroke={darkMode ? '#9CA3AF' : '#6B7280'} />
                    <YAxis stroke={darkMode ? '#9CA3AF' : '#6B7280'} />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="inPatients" fill="#3B82F6" />
                    <Bar dataKey="outPatients" fill="#10B981" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Recent Patients Table */}
          <div className={`${darkMode ? 'bg-gray-800' : 'bg-white'} rounded-xl shadow-lg overflow-hidden`}>
            <div className="p-6">
              <h3 className={`text-lg font-semibold ${darkMode ? 'text-white' : 'text-gray-800'}`}>
                Recent Patients
              </h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className={darkMode ? 'bg-gray-700' : 'bg-gray-50'}>
                  <tr>
                    <th className={`px-6 py-3 text-left text-xs font-medium ${darkMode ? 'text-gray-300' : 'text-gray-500'} uppercase tracking-wider`}>Name</th>
                    <th className={`px-6 py-3 text-left text-xs font-medium ${darkMode ? 'text-gray-300' : 'text-gray-500'} uppercase tracking-wider`}>Age</th>
                    <th className={`px-6 py-3 text-left text-xs font-medium ${darkMode ? 'text-gray-300' : 'text-gray-500'} uppercase tracking-wider`}>Disease</th>
                    <th className={`px-6 py-3 text-left text-xs font-medium ${darkMode ? 'text-gray-300' : 'text-gray-500'} uppercase tracking-wider`}>Status</th>
                    <th className={`px-6 py-3 text-left text-xs font-medium ${darkMode ? 'text-gray-300' : 'text-gray-500'} uppercase tracking-wider`}>Admitted</th>
                  </tr>
                </thead>
                <tbody className={`divide-y ${darkMode ? 'divide-gray-700' : 'divide-gray-200'}`}>
                  {recentPatients.map((patient) => (
                    <tr key={patient.id}>
                      <td className={`px-6 py-4 whitespace-nowrap ${darkMode ? 'text-gray-300' : 'text-gray-800'}`}>{patient.name}</td>
                      <td className={`px-6 py-4 whitespace-nowrap ${darkMode ? 'text-gray-300' : 'text-gray-800'}`}>{patient.age}</td>
                      <td className={`px-6 py-4 whitespace-nowrap ${darkMode ? 'text-gray-300' : 'text-gray-800'}`}>{patient.disease}</td>
                      <td className={`px-6 py-4 whitespace-nowrap ${darkMode ? 'text-gray-300' : 'text-gray-800'}`}>{patient.status}</td>
                      <td className={`px-6 py-4 whitespace-nowrap ${darkMode ? 'text-gray-300' : 'text-gray-800'}`}>{patient.admitted}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
import React, { useState, useRef } from 'react';
import { LayoutDashboard, FlaskRound, UserCircle, Settings, MessageSquare, LogOut, Moon, Sun, Stethoscope, Upload, Play, Pause, AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface ClinicalParameters {
  fev1fvc: number;
  pO2: number;
  pCO2: number;
  crp: number;
  dlco: number;
  bnp: number;
  ahi: number;
}

interface FilePreview {
  name: string;
  type: string;
  url: string;
}

const Test = () => {
  const navigate = useNavigate();
  const [darkMode, setDarkMode] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [files, setFiles] = useState<FilePreview[]>([]);
  const [parameters, setParameters] = useState<ClinicalParameters>({
    fev1fvc: 80,
    pO2: 75,
    pCO2: 35,
    crp: 4,
    dlco: 75,
    bnp: 99,
    ahi: 4
  });
  const [diagnosis, setDiagnosis] = useState<string | null>(null);
  const [affectedParameters, setAffectedParameters] = useState<string[]>([]);
  const audioRef = useRef<HTMLAudioElement>(null);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    document.documentElement.classList.toggle('dark');
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFiles = event.target.files;
    if (!uploadedFiles) return;

    const newFiles: FilePreview[] = Array.from(uploadedFiles).map(file => ({
      name: file.name,
      type: file.type.startsWith('image/') ? 'image' : 'audio',
      url: URL.createObjectURL(file)
    }));

    setFiles([...files, ...newFiles]);
  };

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleParameterChange = (param: keyof ClinicalParameters, value: number) => {
    setParameters(prev => ({ ...prev, [param]: value }));
  };

  const detectDisease = () => {
    const { fev1fvc, pO2, pCO2, crp, dlco, bnp, ahi } = parameters;
    const affected: string[] = [];

    // COPD
    if (fev1fvc <= 50 && pO2 <= 50 && pCO2 >= 55 && dlco <= 40) {
      setDiagnosis('Chronic Obstructive Pulmonary Disease (COPD)');
      affected.push('FEV1/FVC', 'pO2', 'pCO2', 'DLCO');
      setAffectedParameters(affected);
      return;
    }

    // Tuberculosis
    if (fev1fvc <= 60 && pO2 <= 55 && dlco <= 50 && bnp >= 250) {
      setDiagnosis('Tuberculosis');
      affected.push('FEV1/FVC', 'pO2', 'DLCO', 'BNP');
      setAffectedParameters(affected);
      return;
    }

    // Pneumonia
    if (pO2 <= 65 && pCO2 <= 50 && crp > 25 && dlco <= 65 && bnp >= 150) {
      setDiagnosis('Pneumonia');
      affected.push('pO2', 'pCO2', 'CRP', 'DLCO', 'BNP');
      setAffectedParameters(affected);
      return;
    }

    // Asthma
    if (fev1fvc <= 70) {
      setDiagnosis('Asthma');
      affected.push('FEV1/FVC');
      setAffectedParameters(affected);
      return;
    }

    // Sleep Apnea
    if (ahi > 10 && bnp >= 200) {
      setDiagnosis('Sleep Apnea');
      affected.push('AHI', 'BNP');
      setAffectedParameters(affected);
      return;
    }

    setDiagnosis('No Disease Detected ✅');
    setAffectedParameters([]);
  };

  return (
    <div className={`min-h-screen flex ${darkMode ? 'dark bg-gray-900' : 'bg-gray-100'}`}>
      {/* Sidebar */}
      <div className={`w-64 ${darkMode ? 'bg-gray-800' : 'bg-white'} shadow-lg`}>
        <div className="p-6">
          <div className="flex items-center gap-3 mb-8">
            <Stethoscope className={`h-8 w-8 ${darkMode ? 'text-blue-400' : 'text-blue-600'}`} />
            <span className={`text-xl font-bold ${darkMode ? 'text-white' : 'text-gray-800'}`}>MediTech AI</span>
          </div>
          
          <nav className="space-y-2">
            {[
              { icon: LayoutDashboard, text: 'Dashboard', path: '/dashboard' },
              { icon: FlaskRound, text: 'Tests', path: '/test' },
              { icon: UserCircle, text: 'Profile' },
              { icon: Settings, text: 'Settings' },
              { icon: MessageSquare, text: 'Consultation' },
              { icon: LogOut, text: 'Logout' }
            ].map((item, index) => (
              <button
                key={index}
                onClick={() => item.path && navigate(item.path)}
                className={`w-full flex items-center gap-3 px-4 py-2 rounded-lg transition-colors
                  ${darkMode 
                    ? 'text-gray-300 hover:bg-gray-700 hover:text-white' 
                    : 'text-gray-600 hover:bg-blue-50 hover:text-blue-600'}`}
              >
                <item.icon className="h-5 w-5" />
                <span>{item.text}</span>
              </button>
            ))}
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-8">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="flex justify-between items-center mb-8">
            <div>
              <h1 className={`text-2xl font-bold ${darkMode ? 'text-white' : 'text-gray-800'}`}>
                Respiratory Disease Detection
              </h1>
              <p className={`${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                Upload medical data and enter clinical parameters
              </p>
            </div>
            <button
              onClick={toggleDarkMode}
              className={`p-2 rounded-lg ${darkMode ? 'bg-gray-700 text-yellow-400' : 'bg-gray-200 text-gray-600'}`}
            >
              {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </button>
          </div>

          {/* Upload Section */}
          <div className={`${darkMode ? 'bg-gray-800' : 'bg-white'} rounded-xl shadow-lg p-6 mb-8`}>
            <h2 className={`text-lg font-semibold mb-4 ${darkMode ? 'text-white' : 'text-gray-800'}`}>
              Upload Medical Data
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-4">
                <label className={`block text-sm font-medium ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                  CT Scan
                </label>
                <div className="flex items-center justify-center w-full">
                  <label className="w-full flex flex-col items-center px-4 py-6 bg-white text-blue rounded-lg shadow-lg tracking-wide uppercase border border-blue cursor-pointer hover:bg-blue-50 transition-colors">
                    <Upload className="w-8 h-8 text-blue-600" />
                    <span className="mt-2 text-sm text-gray-600">Select CT Scan</span>
                    <input type='file' className="hidden" accept="image/*" onChange={handleFileUpload} />
                  </label>
                </div>
              </div>

              <div className="space-y-4">
                <label className={`block text-sm font-medium ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                  Chest X-Ray
                </label>
                <div className="flex items-center justify-center w-full">
                  <label className="w-full flex flex-col items-center px-4 py-6 bg-white text-blue rounded-lg shadow-lg tracking-wide uppercase border border-blue cursor-pointer hover:bg-blue-50 transition-colors">
                    <Upload className="w-8 h-8 text-blue-600" />
                    <span className="mt-2 text-sm text-gray-600">Select X-Ray</span>
                    <input type='file' className="hidden" accept="image/*" onChange={handleFileUpload} />
                  </label>
                </div>
              </div>

              <div className="space-y-4">
                <label className={`block text-sm font-medium ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                  Breathing Sound
                </label>
                <div className="flex items-center justify-center w-full">
                  <label className="w-full flex flex-col items-center px-4 py-6 bg-white text-blue rounded-lg shadow-lg tracking-wide uppercase border border-blue cursor-pointer hover:bg-blue-50 transition-colors">
                    <Upload className="w-8 h-8 text-blue-600" />
                    <span className="mt-2 text-sm text-gray-600">Select Audio</span>
                    <input type='file' className="hidden" accept="audio/*" onChange={handleFileUpload} />
                  </label>
                </div>
              </div>
            </div>

            {/* Preview Section */}
            {files.length > 0 && (
              <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
                {files.map((file, index) => (
                  <div key={index} className="relative">
                    {file.type === 'image' ? (
                      <img
                        src={file.url}
                        alt={file.name}
                        className="w-full h-48 object-cover rounded-lg"
                      />
                    ) : (
                      <div className="w-full bg-gray-100 rounded-lg p-4">
                        <audio ref={audioRef} src={file.url} className="hidden" />
                        <button
                          onClick={togglePlay}
                          className="flex items-center justify-center w-full gap-2 text-blue-600"
                        >
                          {isPlaying ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6" />}
                          <span>{file.name}</span>
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Clinical Parameters */}
          <div className={`${darkMode ? 'bg-gray-800' : 'bg-white'} rounded-xl shadow-lg p-6 mb-8`}>
            <h2 className={`text-lg font-semibold mb-6 ${darkMode ? 'text-white' : 'text-gray-800'}`}>
              Clinical Parameters
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                { key: 'fev1fvc', label: 'FEV1/FVC Ratio (%)', min: 0, max: 100 },
                { key: 'pO2', label: 'pO2 (mmHg)', min: 0, max: 100 },
                { key: 'pCO2', label: 'pCO2 (mmHg)', min: 0, max: 100 },
                { key: 'crp', label: 'CRP (mg/L)', min: 0, max: 50 },
                { key: 'dlco', label: 'DLCO (%)', min: 0, max: 100 },
                { key: 'bnp', label: 'BNP (pg/mL)', min: 0, max: 500 },
                { key: 'ahi', label: 'AHI (events/hour)', min: 0, max: 50 }
              ].map(({ key, label, min, max }) => (
                <div key={key} className="space-y-2">
                  <label className={`block text-sm font-medium ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    {label}
                  </label>
                  <input
                    type="number"
                    value={parameters[key as keyof ClinicalParameters]}
                    onChange={(e) => handleParameterChange(key as keyof ClinicalParameters, parseFloat(e.target.value))}
                    min={min}
                    max={max}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
              ))}
            </div>

            <button
              onClick={detectDisease}
              className="mt-8 w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 focus:ring-4 focus:ring-blue-500/50 transition-all duration-300 transform hover:scale-[1.02]"
            >
              Analyze Parameters
            </button>
          </div>

          {/* Diagnosis Result */}
          {diagnosis && (
            <div className={`${darkMode ? 'bg-gray-800' : 'bg-white'} rounded-xl shadow-lg p-6`}>
              <div className="flex items-center gap-3 mb-4">
                <AlertCircle className={`h-6 w-6 ${diagnosis.includes('✅') ? 'text-green-500' : 'text-red-500'}`} />
                <h2 className={`text-lg font-semibold ${darkMode ? 'text-white' : 'text-gray-800'}`}>
                  Diagnosis Result
                </h2>
              </div>
              
              <div className={`text-xl font-bold mb-4 ${diagnosis.includes('✅') ? 'text-green-600' : 'text-red-600'}`}>
                {diagnosis}
              </div>

              {affectedParameters.length > 0 && (
                <div className={`mt-4 p-4 rounded-lg ${darkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
                  <h3 className={`text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    Affected Parameters:
                  </h3>
                  <ul className="list-disc list-inside space-y-1">
                    {affectedParameters.map((param, index) => (
                      <li key={index} className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                        {param}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Test;